if(!jQuery("body").hasClass("single-product")) {
(function (angular) {

    angular.bootstrap(document,['VCW_FrontedApp'])

})(angular);
}